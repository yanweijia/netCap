

/**
 * 
 * @author weijia
 * <pre>
 * 在所有的工作之前请先安装winpcap软件
 * 请将本项目libs文件夹中的jpcap.jar添加到BuildPath中,将jpcap.dll文件复制到 %JAVA_HOME%/jre/bin目录下
 * 之后项目正常,可以使用jpcap封装好的类选择抓包网卡进行分析获取数据
 * 参考信息:
 * 配置jpcap:http://blog.csdn.net/fykhlp/article/details/6159195
 * jpcap的使用方法:http://blog.csdn.net/aerchi/article/details/8028997
 * </pre>
 */
public class README {

}
